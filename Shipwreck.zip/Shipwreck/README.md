# Das Boot (Spring Boot course code)

Code written (and copied at times - like the client) as part of a Pluralsight course on Spring Boot.


Common application properties:
https://docs.spring.io/spring-boot/docs/current/reference/html/common-application-properties.html